import React, { Component } from 'react'

class SecondaryFooter extends Component {
    render() {
        return (
            <div>
                Hello Secondary Footer!
            </div>
        )
    }
}

export default SecondaryFooter
