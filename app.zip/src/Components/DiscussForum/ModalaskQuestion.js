import React, { Component } from "react";
import {
  Container,
  Row,
  Col,
  Image,
  Form,
  Button,
  ButtonToolbar
} from "react-bootstrap";
import Avatar from "./../../assets/img/img_avatar.png";

class ModalaskQuestion extends Component {
  constructor(props) {
    super(props);
    this.state = { value: "coconut" };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({ value: event.target.value });
  }

  handleSubmit(event) {
    alert("Your favorite flavor is: " + this.state.value);
    event.preventDefault();
  }
  render() {
    return (
      <div>
        <Container>
          <small>
            <strong>How ask a good question ?</strong>
          </small>

          <ol type="a">
            <small>
              <li>Make sure your question has not been asked already.</li>
            </small>

            <small>
              <li>Keep your question short and to the point.</li>
            </small>

            <small>
              {" "}
              <li>
                You can add maximum five images with your question for better
                understanding.
              </li>
            </small>
            <small>
              {" "}
              <li>Start your question with "What", "How", "Why", etc..</li>
            </small>
          </ol>
          <hr className="mt-1 mb-1" />
          <div className="d-flex bd-highlight">
            <div className="p-2 bd-highlight">
              <Image
                className="user-avatar-post"
                src={Avatar}
                alt="First slide"
              />
            </div>
            <div className="p-2 bd-highlight">
              <small>Username</small>
            </div>
            <div className="ml-auto p-2 bd-highlight">
              <small>
                <form onSubmit={this.handleSubmit}>
                  Asked
                  <select
                    value={this.state.value}
                    onChange={this.handleChange}
                    className="ml-2"
                  >
                    <option value="Public">Public</option>
                    <option value="Architecture">Architecture</option>
                    <option value="Student">Student</option>
                    <option value="Professor">Professor</option>
                    <option value="University/College">
                      University/College
                    </option>
                    <option value="Firm">Firm</option>
                  </select>
                </form>
              </small>
            </div>
          </div>
          <hr className="mt-1 mb-1" />
          <Row>
            <Col>
              <Form>
                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Control
                    type="text"
                    plaintext
                    placeholder="Write the title..."
                  />
                  <hr className="mt-1 mb-1" />
                  <Form.Control
                    as="textarea"
                    rows="3"
                    plaintext
                    placeholder="Write something here..."
                  />
                  <Form.Text className="text-muted">
                    <small>Max 250 words.</small>
                  </Form.Text>
                </Form.Group>
              </Form>
            </Col>
          </Row>
          <hr className="mt-0 mb-2" />
          <div className="d-flex bd-highlight">
            <div className="ml-auto p-2 bd-highlight">
              <ButtonToolbar>
                <Button variant="outline-primary" size="sm">
                  Add Question
                </Button>
              </ButtonToolbar>
            </div>
          </div>
        </Container>
      </div>
    );
  }
}

export default ModalaskQuestion;
