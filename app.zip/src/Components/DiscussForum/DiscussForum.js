import React, { Component } from "react";
import { Container, Row, Col, Carousel, Image } from "react-bootstrap";
import Firstslide from "./../../assets/img/slide-1.jpg";
import Secondslide from "./../../assets/img/slide-2.jpg";
import Thirdslide from "./../../assets/img/slide-3.jpg";
import Fourthslide from "./../../assets/img/slide-4.jpg";
import Fifthslide from "./../../assets/img/slide-5.jpg";
import Avatar from "./../../assets/img/img_avatar.png";

const styles = {
  Image: {
    height: "155px"
  }
};

class DiscussForum extends Component {
  render() {
    return (
      <div>
        {/* Hello */}
        <div className="mt-4 mb-4">
          <Container>
            <Row>
              <Col sm={8}>
                <Row className="row-content-bg">
                  <Col sm={4}>
                    <Carousel className="mt-3">
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Firstslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Secondslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Thirdslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fourthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fifthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                    </Carousel>
                  </Col>
                  <Col sm={8}>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Answer</a>
                          <a href="#T2">Save</a>
                          <a href="#T3">Edit</a>
                          <a href="#T4">Downvote</a>
                          <a href="#T5">Report</a>
                          <a href="#T6">Hide</a>
                          <a href="#T7">Block</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col sm={6}>
                        <small>Answered DD MM YYYY</small>
                      </Col>
                      <Col sm={6}>
                        <small>
                          Last update 2h ago, Username
                          <Image
                            className="user-avatar"
                            src={Avatar}
                            alt="First slide"
                          />
                        </small>
                      </Col>
                      <Col sm={10}>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-pencil-square-o"
                              aria-hidden="true"
                            >
                              <small> 2</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                        </div>
                      </Col>
                      <Col sm={2}>
                        <div className="p-2 bd-highlight">
                          <i className="fa fa-share-alt" aria-hidden="true">
                            <small> 15</small>
                          </i>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-bg mt-3">
                  <Col sm={4}>
                    <Carousel className="mt-3">
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Firstslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Secondslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Thirdslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fourthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fifthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                    </Carousel>
                  </Col>
                  <Col sm={8}>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Answer</a>
                          <a href="#T2">Save</a>
                          <a href="#T3">Edit</a>
                          <a href="#T4">Downvote</a>
                          <a href="#T5">Report</a>
                          <a href="#T6">Hide</a>
                          <a href="#T7">Block</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content.<a href="#T2">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col sm={6}>
                        <small>Answered DD MM YYYY</small>
                      </Col>
                      <Col sm={6}>
                        <small>
                          Last update 2h ago, Username
                          <Image
                            className="user-avatar"
                            src={Avatar}
                            alt="First slide"
                          />
                        </small>
                      </Col>
                      <Col sm={10}>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-pencil-square-o"
                              aria-hidden="true"
                            >
                              <small> 2</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-commenting" aria-hidden="true">
                              <small> 9</small>
                            </i>
                          </div>
                        </div>
                      </Col>
                      <Col sm={2}>
                        <div className="p-2 bd-highlight">
                          <i className="fa fa-share-alt" aria-hidden="true">
                            <small> 15</small>
                          </i>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-bg mt-3">
                  <Col sm={4}>
                    <Carousel className="mt-3">
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Firstslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Secondslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Thirdslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fourthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fifthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                    </Carousel>
                  </Col>
                  <Col sm={8}>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Answer</a>
                          <a href="#T2">Save</a>
                          <a href="#T3">Edit</a>
                          <a href="#T4">Downvote</a>
                          <a href="#T5">Report</a>
                          <a href="#T6">Hide</a>
                          <a href="#T7">Block</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T3">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col sm={6}>
                        <small>Answered DD MM YYYY</small>
                      </Col>
                      <Col sm={6}>
                        <small>
                          Last update 2h ago, Username
                          <Image
                            className="user-avatar"
                            src={Avatar}
                            alt="First slide"
                          />
                        </small>
                      </Col>
                      <Col sm={10}>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-pencil-square-o"
                              aria-hidden="true"
                            >
                              <small> 2</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-commenting" aria-hidden="true">
                              <small> 9</small>
                            </i>
                          </div>
                        </div>
                      </Col>
                      <Col sm={2}>
                        <div className="p-2 bd-highlight">
                          <i className="fa fa-share-alt" aria-hidden="true">
                            <small> 15</small>
                          </i>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-bg mt-3">
                  <Col sm={4}>
                    <Carousel className="mt-3">
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Firstslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Secondslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Thirdslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fourthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                      <Carousel.Item>
                        <Image
                          style={styles.Image}
                          className="d-block w-100"
                          src={Fifthslide}
                          alt="First slide"
                        />
                      </Carousel.Item>
                    </Carousel>
                  </Col>
                  <Col sm={8}>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Answer</a>
                          <a href="#T2">Save</a>
                          <a href="#T3">Edit</a>
                          <a href="#T4">Downvote</a>
                          <a href="#T5">Report</a>
                          <a href="#T6">Hide</a>
                          <a href="#T7">Block</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T4">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col sm={6}>
                        <small>Answered DD MM YYYY</small>
                      </Col>
                      <Col sm={6}>
                        <small>
                          Last update 2h ago, Username
                          <Image
                            className="user-avatar"
                            src={Avatar}
                            alt="First slide"
                          />
                        </small>
                      </Col>
                      <Col sm={10}>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-pencil-square-o"
                              aria-hidden="true"
                            >
                              <small> 2</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-commenting" aria-hidden="true">
                              <small> 9</small>
                            </i>
                          </div>
                        </div>
                      </Col>
                      <Col sm={2}>
                        <div className="p-2 bd-highlight">
                          <i className="fa fa-share-alt" aria-hidden="true">
                            <small> 15</small>
                          </i>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
              <Col sm={4}>
                <Container>
                  <Row>
                    <Col className="forum-home-right-div-content">
                      <div className="mt-3 mb-3">
                        <h6 className="h6-heading mt-2 mb-2">Category</h6>
                        <div className="list-group">
                          <a
                            href="#T1"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Asked questions</small>
                          </a>
                          <a
                            href="#T2"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Given answer</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Reputation </small>
                            <small> 25</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Saved</small>
                          </a>
                        </div>
                        <br />
                        <h6 className="h6-heading mt-2 mb-2">Tags</h6>
                        <div className="list-group">
                          <a
                            href="#T4"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Architecture</small>
                          </a>
                          <a
                            href="#T1"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Student</small>
                          </a>
                          <a
                            href="#T2"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Professor</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by University/College</small>
                          </a>
                          <a
                            href="#T4"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Firms</small>
                          </a>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </Container>
              </Col>
            </Row>
          </Container>
        </div>
      </div>
    );
  }
}

export default DiscussForum;
