import React, { Component } from "react";
import { Container, Row, Col, Image } from "react-bootstrap";
import Avatar from "./../../assets/img/img_avatar.png";

class AskedQuestion extends Component {
  render() {
    return (
      <div>
        <div className="mt-4 mb-4">
          <Container>
            <Row>
              <Col sm={8}>
                <Row className="row-content-aq-bg">
                  <Col>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Edit Question</a>
                          <a href="#T2">Delete Question </a>
                          <a href="#T3">Save Question</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answer </small>
                            <small> 2</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-eye" aria-hidden="true">
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-share-alt" aria-hidden="true">
                              <small> 15</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answered DD MM YYYY by Username</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>
                              Last update 2h ago, Username
                              <Image
                                className="user-avatar"
                                src={Avatar}
                                alt="First slide"
                              />
                            </small>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-aq-bg mt-3">
                  <Col>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Edit Question</a>
                          <a href="#T2">Delete Question </a>
                          <a href="#T3">Save Question</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answer </small>
                            <small> 2</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-eye" aria-hidden="true">
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-share-alt" aria-hidden="true">
                              <small> 15</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answered DD MM YYYY by Username</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>
                              Last update 2h ago, Username
                              <Image
                                className="user-avatar"
                                src={Avatar}
                                alt="First slide"
                              />
                            </small>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-aq-bg mt-3">
                  <Col>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Edit Question</a>
                          <a href="#T2">Delete Question </a>
                          <a href="#T3">Save Question</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answer </small>
                            <small> 2</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-eye" aria-hidden="true">
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-share-alt" aria-hidden="true">
                              <small> 15</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answered DD MM YYYY by Username</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>
                              Last update 2h ago, Username
                              <Image
                                className="user-avatar"
                                src={Avatar}
                                alt="First slide"
                              />
                            </small>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-aq-bg mt-3">
                  <Col>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Edit Question</a>
                          <a href="#T2">Delete Question </a>
                          <a href="#T3">Save Question</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answer </small>
                            <small> 2</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-eye" aria-hidden="true">
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-share-alt" aria-hidden="true">
                              <small> 15</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answered DD MM YYYY by Username</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>
                              Last update 2h ago, Username
                              <Image
                                className="user-avatar"
                                src={Avatar}
                                alt="First slide"
                              />
                            </small>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>

                <Row className="row-content-aq-bg mt-3">
                  <Col>
                    <div className="title-col mt-1">
                      <h6>
                        The Title Some quick example text to build on the card
                        title and make
                      </h6>
                    </div>
                    <div className="icon-col d-flex align-items-end flex-column">
                      <div className="dropdown">
                        <div className="dropbtnicon" id="dropdown-split-basic">
                          <i
                            className="fa fa-ellipsis-v"
                            aria-hidden="true"
                          ></i>
                        </div>
                        <div className="dropdown-content">
                          <a href="#T1">Edit Question</a>
                          <a href="#T2">Delete Question </a>
                          <a href="#T3">Save Question</a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <small>
                        Some quick example text to build on the card title and
                        make up the bulk of the card's content. Some quick
                        example text to build on the card title and make up the
                        bulk of the card's content. <a href="#T1">Read More</a>
                      </small>
                    </div>
                    <Row>
                      <Col>
                        <div className="d-flex flex-row bd-highlight">
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-long-arrow-up"
                              aria-hidden="true"
                            >
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answer </small>
                            <small> 2</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-eye" aria-hidden="true">
                              <small> 5</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i
                              className="fa fa-commenting"
                              aria-hidden="true"
                            ></i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <i className="fa fa-share-alt" aria-hidden="true">
                              <small> 15</small>
                            </i>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>Answered DD MM YYYY by Username</small>
                          </div>
                          <div className="p-2 bd-highlight">
                            <small>
                              Last update 2h ago, Username
                              <Image
                                className="user-avatar"
                                src={Avatar}
                                alt="First slide"
                              />
                            </small>
                          </div>
                        </div>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
              <Col sm={4}>
                <Container>
                  <Row>
                    <Col className="forum-home-right-div-content">
                      <div className="mt-3 mb-3">
                        <h6 className="h6-heading mt-2 mb-2">Category</h6>
                        <div className="list-group">
                          <a
                            href="#T1"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Asked questions</small>
                          </a>
                          <a
                            href="#T2"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Given answer</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Reputation </small>
                            <small> 25</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Saved</small>
                          </a>
                        </div>
                        <br />
                        <h6 className="h6-heading mt-2 mb-2">Tags</h6>
                        <div className="list-group">
                          <a
                            href="#T4"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Architecture</small>
                          </a>
                          <a
                            href="#T1"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Student</small>
                          </a>
                          <a
                            href="#T2"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Professor</small>
                          </a>
                          <a
                            href="#T3"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by University/College</small>
                          </a>
                          <a
                            href="#T4"
                            className="list-group-item-action mt-1 mb-1"
                          >
                            <small>Post by Firms</small>
                          </a>
                        </div>
                      </div>
                    </Col>
                  </Row>
                </Container>
              </Col>
            </Row>
          </Container>
        </div>
      </div>
    );
  }
}

export default AskedQuestion;
