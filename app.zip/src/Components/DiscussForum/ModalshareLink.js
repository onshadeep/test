import React, { Component } from "react";
import {
  Container,
  Row,
  Col,
  Image,
  Form,
  Button,
  ButtonToolbar,
  InputGroup,
  FormControl
} from "react-bootstrap";
import Avatar from "./../../assets/img/img_avatar.png";

class ModalshareLink extends Component {
  constructor(props) {
    super(props);
    this.state = { value: "coconut" };

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({ value: event.target.value });
  }

  handleSubmit(event) {
    alert("Your favorite flavor is: " + this.state.value);
    event.preventDefault();
  }
  render() {
    return (
      <div>
        <Container>
          <div className="d-flex bd-highlight">
            <div className="p-2 bd-highlight">
              <Image
                className="user-avatar-post"
                src={Avatar}
                alt="First slide"
              />
            </div>
            <div className="p-2 bd-highlight">
              <small>Username</small>
            </div>
            <div className="ml-auto p-2 bd-highlight">
              <small>
                <form onSubmit={this.handleSubmit}>
                  Asked
                  <select
                    value={this.state.value}
                    onChange={this.handleChange}
                    className="ml-2"
                  >
                    <option value="Public">Public</option>
                    <option value="Architecture">Architecture</option>
                    <option value="Student">Student</option>
                    <option value="Professor">Professor</option>
                    <option value="University/College">
                      University/College
                    </option>
                    <option value="Firm">Firm</option>
                  </select>
                </form>
              </small>
            </div>
          </div>
          <hr className="mt-1 mb-2" />
          <Row>
            <Col>
              <InputGroup className="mb-3">
                <InputGroup.Prepend>
                  <InputGroup.Text id="basic-addon3">Link</InputGroup.Text>
                </InputGroup.Prepend>
                <FormControl
                  id="basic-url"
                  placeholder="https://example.com/users/"
                  aria-describedby="basic-addon3"
                />
              </InputGroup>
            </Col>
          </Row>
          <Row>
            <Col>
              <Form>
                <Form.Group controlId="exampleForm.ControlTextarea1">
                  <Form.Control
                    as="textarea"
                    rows="3"
                    plaintext
                    placeholder="Write something about this..."
                  />
                  <Form.Text className="text-muted">
                    <small>Max 250 words.</small>
                  </Form.Text>
                </Form.Group>
              </Form>
            </Col>
          </Row>

          <hr className="mt-0 mb-2" />
          <div className="d-flex bd-highlight">
            <div className="ml-auto p-2 bd-highlight">
              <ButtonToolbar>
                <Button variant="outline-primary" size="sm">
                  Share Link
                </Button>
              </ButtonToolbar>
            </div>
          </div>
        </Container>
      </div>
    );
  }
}

export default ModalshareLink;
