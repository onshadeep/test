import React, { Component } from 'react'

class PostQuestion extends Component {
    render() {
        return (
            <div>
                Hello !
            </div>
        )
    }
}

export default PostQuestion
