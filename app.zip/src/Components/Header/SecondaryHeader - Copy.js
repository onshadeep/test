import React, { Component } from "react";
import { Nav, Form, FormControl, Button, ButtonToolbar, Navbar } from "react-bootstrap";


const styles = {
  Navlink: {
    color: "#2a2f42"
  }
};

class SecondaryHeader extends Component {
  render() {
    return (
      <div>
        <Navbar
          collapseOnSelect
          expand="lg"
          style={styles.Navbar}
          className="sec-nav-bg"
          variant="dark"
        >
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="#T1" style={styles.Navlink}>
                Feed
              </Nav.Link>
              <Nav.Link href="#T2" style={styles.Navlink}>
                Bulletin
              </Nav.Link>
              <Nav.Link href="#T3" style={styles.Navlink}>
                Favourites
              </Nav.Link>
              <Nav.Link href="#T4" style={styles.Navlink}>
                Forum
              </Nav.Link>
            </Nav>
            <Nav>
              <Nav.Link href="#T5" style={styles.Navlink}>
                Home
              </Nav.Link>
              <Nav.Link href="#T6" style={styles.Navlink}>
                Notification
              </Nav.Link>
              <Nav.Link href="#T7" style={styles.Navlink}>
                Answer
              </Nav.Link>
            </Nav>
            <ButtonToolbar className="d-flex flex-column">
              <Button variant="danger" size="sm" className="mr-2">
                Ask Question
              </Button>
            </ButtonToolbar>
            <Form inline>
              <FormControl
                className="d-flex flex-column mr-2 search-border"
                type="text"
                placeholder="Search"
                size="sm"
              />
            </Form>
          </Navbar.Collapse>
        </Navbar>
      </div>
    );
  }
}

export default SecondaryHeader;
