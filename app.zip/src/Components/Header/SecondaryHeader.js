import React, { useState } from "react";
import {
  Nav,
  Form,
  FormControl,
  Button,
  ButtonToolbar,
  Navbar,
  Container,
  Row,
  Col,
  Tabs,
  Tab,
  Modal
} from "react-bootstrap";
import ModalaskQuestion from "../DiscussForum/ModalaskQuestion";
import ModalshareLink from "../DiscussForum/ModalshareLink";

const styles = {
  Navlink: {
    color: "#2a2f42"
  }
};

function SecondaryHeader() {
  const [lgShow, setLgShow] = useState(false);
  const [key, setKey] = useState("Addque");

  return (
    <div>
      <Navbar
        collapseOnSelect
        expand="lg"
        style={styles.Navbar}
        className="sec-nav-bg"
        variant="dark"
      >
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="mr-auto">
            <Nav.Link href="#T1" style={styles.Navlink}>
              Feed
            </Nav.Link>
            <Nav.Link href="#T2" style={styles.Navlink}>
              Bulletin
            </Nav.Link>
            <Nav.Link href="#T3" style={styles.Navlink}>
              Favourites
            </Nav.Link>
            <Nav.Link href="#T4" style={styles.Navlink}>
              Forum
            </Nav.Link>
          </Nav>
          <Nav>
            <Nav.Link href="#T5" style={styles.Navlink}>
              Home
            </Nav.Link>
            <Nav.Link href="#T6" style={styles.Navlink}>
              Notification
            </Nav.Link>
            <Nav.Link href="#T7" style={styles.Navlink}>
              Answer
            </Nav.Link>
          </Nav>
          <ButtonToolbar>
            <Button
              variant="danger"
              size="sm"
              onClick={() => setLgShow(true)}
              className="button  mr-2"
            >
              Ask Question
            </Button>
            <Modal
              size="lg"
              show={lgShow}
              onHide={() => setLgShow(false)}
              aria-labelledby="example-modal-sizes-title-lg"
            >
              <Modal.Header closeButton>
                <Modal.Title id="example-modal-sizes-title-lg">
                  <small>Ask Question</small>
                </Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <Container className="mb-3">
                  <Row>
                    <Col>
                      <small>
                        You are ready to ask your first question and the
                        community is have to help to get you the best answers,
                        we have provided some guidence.
                      </small>
                    </Col>
                  </Row>
                </Container>

                <Tabs
                  id="controlled-tab-example"
                  activeKey={key}
                  onSelect={k => setKey(k)}
                >
                  <Tab eventKey="Addque" title="Add Question">
                    <ModalaskQuestion />
                  </Tab>

                  <Tab eventKey="profile" title="Share Link">
                    <ModalshareLink />
                  </Tab>
                </Tabs>
              </Modal.Body>
              {/* <Modal.Footer>
            <Row>
              <Col className="d-flex align-items-end flex-column bd-highlight">
                <Button color="primary">Save Post</Button>
              </Col>
            </Row>
        </Modal.Footer> */}
            </Modal>
          </ButtonToolbar>
          <Form inline>
            <FormControl
              className="d-flex flex-column mr-2 search-border"
              type="text"
              placeholder="Search"
              size="sm"
            />
          </Form>
        </Navbar.Collapse>
      </Navbar>
    </div>
  );
}

export default SecondaryHeader;
