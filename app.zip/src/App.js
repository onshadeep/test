import React from "react";
// import logo from './logo.svg';
import "./App.css";
import "./assets/css/SiteAgora.css";
import PrimaryHeader from "./Components/Header/PrimaryHeader";
import PrimaryFooter from "./Components/Footer/PrimaryFooter";
import SecondaryHeader from "./Components/Header/SecondaryHeader";
import PostQuestion from "./Components/DiscussForum/PostQuestion";
// import AllSaved from "./Components/DiscussForum/AllSaved";
// import AskedQuestion from "./Components/DiscussForum/AskedQuestion";
// import GivenAnswer from "./Components/DiscussForum/GivenAnswer";
// import DiscussForum from "./Components/DiscussForum/DiscussForum";

function App() {
  return (
    <div className="App">
      <PrimaryHeader />
      <SecondaryHeader />
      {/* <DiscussForum /> */}
      {/* <AskedQuestion /> */}
      {/* <GivenAnswer /> */}
      {/* <AllSaved /> */}
      <PostQuestion />
      <PrimaryFooter />
    </div>
  );
}

export default App;
